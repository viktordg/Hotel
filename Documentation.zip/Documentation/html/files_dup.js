var files_dup =
[
    [ "Date.cpp", "_date_8cpp.html", null ],
    [ "Date.h", "_date_8h.html", [
      [ "Date", "class_date.html", "class_date" ]
    ] ],
    [ "Hotel.cpp", "_hotel_8cpp.html", null ],
    [ "Hotel.h", "_hotel_8h.html", [
      [ "Hotel", "class_hotel.html", "class_hotel" ]
    ] ],
    [ "project_1_Hotel.cpp", "project__1___hotel_8cpp.html", "project__1___hotel_8cpp" ],
    [ "Room.cpp", "_room_8cpp.html", null ],
    [ "Room.h", "_room_8h.html", [
      [ "Room", "class_room.html", "class_room" ]
    ] ],
    [ "stdafx.cpp", "stdafx_8cpp.html", null ],
    [ "stdafx.h", "stdafx_8h.html", null ],
    [ "targetver.h", "targetver_8h.html", null ]
];