var annotated_dup =
[
    [ "Date", "class_date.html", "class_date" ],
    [ "Hotel", "class_hotel.html", "class_hotel" ],
    [ "Room", "class_room.html", "class_room" ]
];