var class_hotel =
[
    [ "Hotel", "class_hotel.html#a59cc2c3a373abece5a25d730524be2f0", null ],
    [ "add_room", "class_hotel.html#a1fc874696b0e47026a86845785d97b22", null ],
    [ "availability", "class_hotel.html#ac082f1210d6893bad0da55aa00edfce7", null ],
    [ "checkin", "class_hotel.html#a6d5e124cd850b5351cc64e480cea2e3b", null ],
    [ "checkout", "class_hotel.html#a84edb71bffeec4ea16db39ba600dc46f", null ],
    [ "countLeapYears", "class_hotel.html#ab110fbdc0a4a56f963e6e215dfe83201", null ],
    [ "daysBetweenTwoDates", "class_hotel.html#a330f7b11dd6825eaa9aceb0c1c5aa351", null ],
    [ "find", "class_hotel.html#a0e643c11bdbceb831df7f067d5e80d78", null ],
    [ "isFree", "class_hotel.html#a571420ca46d238c52737a19a9344fbfc", null ],
    [ "print", "class_hotel.html#ae53b1ad03b24d52c98e47f296da07196", null ],
    [ "report", "class_hotel.html#ad171c1a2aa955c10b16be3222b3b5602", null ],
    [ "sortRoomsByBedCount", "class_hotel.html#aa32ea42a80c8af601b69d84056b7d6d3", null ],
    [ "unavailable", "class_hotel.html#a0ae20bdccac171bd43f1c24e5687c645", null ],
    [ "VIP_find", "class_hotel.html#abff6901218c96643e4cdfad7e232f208", null ],
    [ "rooms", "class_hotel.html#a16da8c14e35900d8455c97e6dd62b0fc", null ]
];