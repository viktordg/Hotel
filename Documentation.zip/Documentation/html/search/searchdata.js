var indexSectionsWithContent =
{
  0: "abcdefghimnoprstuvy",
  1: "dhr",
  2: "dhiprst",
  3: "acdfghimoprsuv",
  4: "bdegmnrsy"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables"
};

