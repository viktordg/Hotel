var searchData=
[
  ['startdate_125',['startDate',['../class_room.html#a94e36881b70913044d32d703281efbce',1,'Room']]]
];
