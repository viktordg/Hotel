var searchData=
[
  ['add_5froom_0',['add_room',['../class_hotel.html#a1fc874696b0e47026a86845785d97b22',1,'Hotel']]],
  ['availability_1',['availability',['../class_hotel.html#ac082f1210d6893bad0da55aa00edfce7',1,'Hotel']]]
];
