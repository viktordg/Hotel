var a00861 =
[
    [ "Hotel", "dd/dd5/a00861.html#a21c9a33a3bd2749b16bacc868896c01d", null ],
    [ "add_room", "dd/dd5/a00861.html#ac75dd352bfbef207b8bd78aa8ed32362", null ],
    [ "availability", "dd/dd5/a00861.html#aef9516b9959d1ca118924609d14690d8", null ],
    [ "checkin", "dd/dd5/a00861.html#aeac828a701105e76cd437d38dfdff240", null ],
    [ "checkout", "dd/dd5/a00861.html#a75101e30c7330012a0fc8d979efc673a", null ],
    [ "countLeapYears", "dd/dd5/a00861.html#a9975597c519911e07014a35c85c49306", null ],
    [ "daysBetweenTwoDates", "dd/dd5/a00861.html#a84a3046ac54fc4db044fc1d23b496813", null ],
    [ "find", "dd/dd5/a00861.html#a0a49b7969e10575de37e8aba7c4dd937", null ],
    [ "isFree", "dd/dd5/a00861.html#a16f6bbc3369852ca579193434a8262e8", null ],
    [ "print", "dd/dd5/a00861.html#ae5cb5af1b77615794d50572367881333", null ],
    [ "report", "dd/dd5/a00861.html#a669000024ceb6e7849af5a21038f70fc", null ],
    [ "sortRoomsByBedCount", "dd/dd5/a00861.html#a170cf185f926dcea69eb90688cdffac3", null ],
    [ "unavailable", "dd/dd5/a00861.html#a8dc1fb5216d4613f733534d3966ef3c1", null ],
    [ "VIP_find", "dd/dd5/a00861.html#a20086835a2ab355edd9d113f216d5726", null ],
    [ "rooms", "dd/dd5/a00861.html#a9082f9b539870f5992c32d1484562a62", null ]
];