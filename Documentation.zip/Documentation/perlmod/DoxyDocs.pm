$doxydocs=
{
  classes => [
    {
      name => 'Date',
      includes => {
        local => 'no',
        name => 'Date.h'
      },
      all_members => [
        {
          name => 'Date',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Date'
        },
        {
          name => 'Date',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Date'
        },
        {
          name => 'day',
          virtualness => 'non_virtual',
          protection => 'private',
          scope => 'Date'
        },
        {
          name => 'get_day',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Date'
        },
        {
          name => 'get_month',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Date'
        },
        {
          name => 'get_year',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Date'
        },
        {
          name => 'month',
          virtualness => 'non_virtual',
          protection => 'private',
          scope => 'Date'
        },
        {
          name => 'operator!=',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Date'
        },
        {
          name => 'operator<',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Date'
        },
        {
          name => 'operator<=',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Date'
        },
        {
          name => 'operator=',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Date'
        },
        {
          name => 'operator==',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Date'
        },
        {
          name => 'operator>',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Date'
        },
        {
          name => 'operator>=',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Date'
        },
        {
          name => 'set_day',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Date'
        },
        {
          name => 'set_month',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Date'
        },
        {
          name => 'set_year',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Date'
        },
        {
          name => 'year',
          virtualness => 'non_virtual',
          protection => 'private',
          scope => 'Date'
        }
      ],
      public_methods => {
        members => [
          {
            kind => 'function',
            name => 'Date',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {},
            detailed => {},
            const => 'no',
            volatile => 'no',
            parameters => [
            ]
          },
          {
            kind => 'function',
            name => 'Date',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {},
            detailed => {},
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'day',
                type => 'int'
              },
              {
                declaration_name => 'month',
                type => 'int'
              },
              {
                declaration_name => 'year',
                type => 'int'
              }
            ]
          },
          {
            kind => 'function',
            name => 'operator=',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {},
            detailed => {},
            type => 'Date &',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'other',
                type => 'const Date &'
              }
            ]
          },
          {
            kind => 'function',
            name => 'operator==',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {},
            detailed => {},
            type => 'bool',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'other',
                type => 'const Date &'
              }
            ]
          },
          {
            kind => 'function',
            name => 'operator!=',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {},
            detailed => {},
            type => 'bool',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'other',
                type => 'const Date &'
              }
            ]
          },
          {
            kind => 'function',
            name => 'operator<',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {},
            detailed => {},
            type => 'bool',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'other',
                type => 'const Date &'
              }
            ]
          },
          {
            kind => 'function',
            name => 'operator>',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {},
            detailed => {},
            type => 'bool',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'other',
                type => 'const Date &'
              }
            ]
          },
          {
            kind => 'function',
            name => 'operator<=',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {},
            detailed => {},
            type => 'bool',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'other',
                type => 'const Date &'
              }
            ]
          },
          {
            kind => 'function',
            name => 'operator>=',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {},
            detailed => {},
            type => 'bool',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'other',
                type => 'const Date &'
              }
            ]
          },
          {
            kind => 'function',
            name => 'get_day',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {},
            detailed => {},
            type => 'int',
            const => 'yes',
            volatile => 'no',
            parameters => [
            ]
          },
          {
            kind => 'function',
            name => 'get_month',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {},
            detailed => {},
            type => 'int',
            const => 'yes',
            volatile => 'no',
            parameters => [
            ]
          },
          {
            kind => 'function',
            name => 'get_year',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {},
            detailed => {},
            type => 'int',
            const => 'yes',
            volatile => 'no',
            parameters => [
            ]
          },
          {
            kind => 'function',
            name => 'set_day',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {},
            detailed => {},
            type => 'void',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'day',
                type => 'int'
              }
            ]
          },
          {
            kind => 'function',
            name => 'set_month',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {},
            detailed => {},
            type => 'void',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'month',
                type => 'int'
              }
            ]
          },
          {
            kind => 'function',
            name => 'set_year',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {},
            detailed => {},
            type => 'void',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'year',
                type => 'int'
              }
            ]
          }
        ]
      },
      private_members => {
        members => [
          {
            kind => 'variable',
            name => 'day',
            virtualness => 'non_virtual',
            protection => 'private',
            static => 'no',
            brief => {},
            detailed => {},
            type => 'int'
          },
          {
            kind => 'variable',
            name => 'month',
            virtualness => 'non_virtual',
            protection => 'private',
            static => 'no',
            brief => {},
            detailed => {},
            type => 'int'
          },
          {
            kind => 'variable',
            name => 'year',
            virtualness => 'non_virtual',
            protection => 'private',
            static => 'no',
            brief => {},
            detailed => {},
            type => 'int'
          }
        ]
      },
      brief => {
        doc => [
          {
            type => 'parbreak'
          },
          {
            type => 'text',
            content => 'Class that defines '
          },
          {
            type => 'url',
            link => 'class_date',
            content => 'Date'
          },
          {
            type => 'text',
            content => '. '
          }
        ]
      },
      detailed => {}
    },
    {
      name => 'Hotel',
      includes => {
        local => 'no',
        name => 'Hotel.h'
      },
      all_members => [
        {
          name => 'add_room',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Hotel'
        },
        {
          name => 'availability',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Hotel'
        },
        {
          name => 'checkin',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Hotel'
        },
        {
          name => 'checkout',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Hotel'
        },
        {
          name => 'countLeapYears',
          virtualness => 'non_virtual',
          protection => 'private',
          scope => 'Hotel'
        },
        {
          name => 'daysBetweenTwoDates',
          virtualness => 'non_virtual',
          protection => 'private',
          scope => 'Hotel'
        },
        {
          name => 'find',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Hotel'
        },
        {
          name => 'Hotel',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Hotel'
        },
        {
          name => 'isFree',
          virtualness => 'non_virtual',
          protection => 'private',
          scope => 'Hotel'
        },
        {
          name => 'print',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Hotel'
        },
        {
          name => 'report',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Hotel'
        },
        {
          name => 'rooms',
          virtualness => 'non_virtual',
          protection => 'private',
          scope => 'Hotel'
        },
        {
          name => 'sortRoomsByBedCount',
          virtualness => 'non_virtual',
          protection => 'private',
          scope => 'Hotel'
        },
        {
          name => 'unavailable',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Hotel'
        },
        {
          name => 'VIP_find',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Hotel'
        }
      ],
      public_methods => {
        members => [
          {
            kind => 'function',
            name => 'Hotel',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Default constructor. '
                }
              ]
            },
            detailed => {},
            const => 'no',
            volatile => 'no',
            parameters => [
            ]
          },
          {
            kind => 'function',
            name => 'add_room',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Adds a room to the hotel. '
                }
              ]
            },
            detailed => {},
            type => 'void',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'room',
                type => 'const Room &'
              }
            ]
          },
          {
            kind => 'function',
            name => 'checkin',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Checks in a guest to the hotel if there is an appropriate room. '
                }
              ]
            },
            detailed => {},
            type => 'void',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'room',
                type => 'int'
              },
              {
                declaration_name => 'startingDate',
                type => 'const Date &'
              },
              {
                declaration_name => 'endDate',
                type => 'const Date &'
              },
              {
                declaration_name => 'guests',
                type => 'const std::string &'
              }
            ]
          },
          {
            kind => 'function',
            name => 'availability',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Gives free rooms on a given date. '
                }
              ]
            },
            detailed => {},
            type => 'void',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'date',
                type => 'Date &'
              }
            ]
          },
          {
            kind => 'function',
            name => 'checkout',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Frees up a foom. '
                }
              ]
            },
            detailed => {},
            type => 'void',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'rooms',
                type => 'int'
              }
            ]
          },
          {
            kind => 'function',
            name => 'report',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Returns days of use for each room between two dates. '
                }
              ]
            },
            detailed => {},
            type => 'void',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'startingDate',
                type => 'Date &'
              },
              {
                declaration_name => 'endDate',
                type => 'Date &'
              }
            ]
          },
          {
            kind => 'function',
            name => 'find',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Returns a compatible room. '
                }
              ]
            },
            detailed => {},
            type => 'void',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'beds',
                type => 'int'
              },
              {
                declaration_name => 'startingDate',
                type => 'const Date &'
              },
              {
                declaration_name => 'endDate',
                type => 'const Date &'
              }
            ]
          },
          {
            kind => 'function',
            name => 'VIP_find',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Removes guests from rooms in case the hotel is full so that the VIP guests can be checked in. '
                }
              ]
            },
            detailed => {},
            type => 'void',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'beds',
                type => 'int'
              },
              {
                declaration_name => 'startingDate',
                type => 'const Date &'
              },
              {
                declaration_name => 'endDate',
                type => 'const Date &'
              }
            ]
          },
          {
            kind => 'function',
            name => 'unavailable',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'Makes a room unavailable. '
                }
              ]
            },
            detailed => {},
            type => 'void',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'room',
                type => 'int'
              },
              {
                declaration_name => 'startingDate',
                type => 'const Date &'
              },
              {
                declaration_name => 'endDate',
                type => 'const Date &'
              },
              {
                declaration_name => 'note',
                type => 'const std::string &'
              }
            ]
          },
          {
            kind => 'function',
            name => 'print',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'prins information for each room of the hotel '
                }
              ]
            },
            detailed => {},
            type => 'void',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'file',
                type => 'std::ofstream &'
              }
            ]
          }
        ]
      },
      private_methods => {
        members => [
          {
            kind => 'function',
            name => 'sortRoomsByBedCount',
            virtualness => 'non_virtual',
            protection => 'private',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'sorts the rooms in a hotel by their bed count '
                }
              ]
            },
            detailed => {},
            type => 'void',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'rooms',
                type => 'std::vector< Room >'
              }
            ]
          },
          {
            kind => 'function',
            name => 'isFree',
            virtualness => 'non_virtual',
            protection => 'private',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'isFree check if input dates are compatible with the given room`s dates '
                }
              ]
            },
            detailed => {},
            type => 'bool',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'index',
                type => 'int'
              },
              {
                declaration_name => 'startingDate',
                type => 'const Date &'
              },
              {
                declaration_name => 'endDate',
                type => 'const Date &'
              }
            ]
          },
          {
            kind => 'function',
            name => 'countLeapYears',
            virtualness => 'non_virtual',
            protection => 'private',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'counts leap years used in daysBetweenTwoDates method '
                }
              ]
            },
            detailed => {},
            type => 'int',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'd',
                type => 'const Date &'
              }
            ]
          },
          {
            kind => 'function',
            name => 'daysBetweenTwoDates',
            virtualness => 'non_virtual',
            protection => 'private',
            static => 'no',
            brief => {
              doc => [
                {
                  type => 'parbreak'
                },
                {
                  type => 'text',
                  content => 'counts days between two dates '
                }
              ]
            },
            detailed => {},
            type => 'int',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'firstDate',
                type => 'const Date &'
              },
              {
                declaration_name => 'secondDate',
                type => 'const Date &'
              }
            ]
          }
        ]
      },
      private_members => {
        members => [
          {
            kind => 'variable',
            name => 'rooms',
            virtualness => 'non_virtual',
            protection => 'private',
            static => 'no',
            brief => {},
            detailed => {},
            type => 'std::vector< Room >'
          }
        ]
      },
      brief => {
        doc => [
          {
            type => 'parbreak'
          },
          {
            type => 'text',
            content => 'Class that defines a '
          },
          {
            type => 'url',
            link => 'class_hotel',
            content => 'Hotel'
          },
          {
            type => 'text',
            content => '. '
          }
        ]
      },
      detailed => {}
    },
    {
      name => 'Room',
      includes => {
        local => 'no',
        name => 'Room.h'
      },
      all_members => [
        {
          name => 'bedCount',
          virtualness => 'non_virtual',
          protection => 'private',
          scope => 'Room'
        },
        {
          name => 'endDate',
          virtualness => 'non_virtual',
          protection => 'private',
          scope => 'Room'
        },
        {
          name => 'get_bedCount',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Room'
        },
        {
          name => 'get_endDate',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Room'
        },
        {
          name => 'get_guests',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Room'
        },
        {
          name => 'get_number',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Room'
        },
        {
          name => 'get_startDate',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Room'
        },
        {
          name => 'guests',
          virtualness => 'non_virtual',
          protection => 'private',
          scope => 'Room'
        },
        {
          name => 'number',
          virtualness => 'non_virtual',
          protection => 'private',
          scope => 'Room'
        },
        {
          name => 'Room',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Room'
        },
        {
          name => 'Room',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Room'
        },
        {
          name => 'set_bedCount',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Room'
        },
        {
          name => 'set_endDate',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Room'
        },
        {
          name => 'set_guest',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Room'
        },
        {
          name => 'set_number',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Room'
        },
        {
          name => 'set_startDate',
          virtualness => 'non_virtual',
          protection => 'public',
          scope => 'Room'
        },
        {
          name => 'startDate',
          virtualness => 'non_virtual',
          protection => 'private',
          scope => 'Room'
        }
      ],
      public_methods => {
        members => [
          {
            kind => 'function',
            name => 'Room',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {},
            detailed => {},
            const => 'no',
            volatile => 'no',
            parameters => [
            ]
          },
          {
            kind => 'function',
            name => 'Room',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {},
            detailed => {},
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'number',
                type => 'int'
              },
              {
                declaration_name => 'bedCount',
                type => 'int'
              },
              {
                declaration_name => 'guests',
                type => 'std::string'
              },
              {
                declaration_name => 'startDate',
                type => 'const Date'
              },
              {
                declaration_name => 'endDate',
                type => 'const Date'
              }
            ]
          },
          {
            kind => 'function',
            name => 'get_number',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {},
            detailed => {},
            type => 'int',
            const => 'yes',
            volatile => 'no',
            parameters => [
            ]
          },
          {
            kind => 'function',
            name => 'get_bedCount',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {},
            detailed => {},
            type => 'int',
            const => 'yes',
            volatile => 'no',
            parameters => [
            ]
          },
          {
            kind => 'function',
            name => 'get_guests',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {},
            detailed => {},
            type => 'const std::string',
            const => 'yes',
            volatile => 'no',
            parameters => [
            ]
          },
          {
            kind => 'function',
            name => 'get_startDate',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {},
            detailed => {},
            type => 'Date',
            const => 'yes',
            volatile => 'no',
            parameters => [
            ]
          },
          {
            kind => 'function',
            name => 'get_endDate',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {},
            detailed => {},
            type => 'Date',
            const => 'yes',
            volatile => 'no',
            parameters => [
            ]
          },
          {
            kind => 'function',
            name => 'set_number',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {},
            detailed => {},
            type => 'void',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'number',
                type => 'int'
              }
            ]
          },
          {
            kind => 'function',
            name => 'set_bedCount',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {},
            detailed => {},
            type => 'void',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'bedCount',
                type => 'int'
              }
            ]
          },
          {
            kind => 'function',
            name => 'set_guest',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {},
            detailed => {},
            type => 'void',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'guests',
                type => 'std::string'
              }
            ]
          },
          {
            kind => 'function',
            name => 'set_startDate',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {},
            detailed => {},
            type => 'void',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'other',
                type => 'Date'
              }
            ]
          },
          {
            kind => 'function',
            name => 'set_endDate',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {},
            detailed => {},
            type => 'void',
            const => 'no',
            volatile => 'no',
            parameters => [
              {
                declaration_name => 'other',
                type => 'Date'
              }
            ]
          }
        ]
      },
      private_members => {
        members => [
          {
            kind => 'variable',
            name => 'number',
            virtualness => 'non_virtual',
            protection => 'private',
            static => 'no',
            brief => {},
            detailed => {},
            type => 'int'
          },
          {
            kind => 'variable',
            name => 'bedCount',
            virtualness => 'non_virtual',
            protection => 'private',
            static => 'no',
            brief => {},
            detailed => {},
            type => 'int'
          },
          {
            kind => 'variable',
            name => 'guests',
            virtualness => 'non_virtual',
            protection => 'private',
            static => 'no',
            brief => {},
            detailed => {},
            type => 'std::string'
          },
          {
            kind => 'variable',
            name => 'startDate',
            virtualness => 'non_virtual',
            protection => 'private',
            static => 'no',
            brief => {},
            detailed => {},
            type => 'Date'
          },
          {
            kind => 'variable',
            name => 'endDate',
            virtualness => 'non_virtual',
            protection => 'private',
            static => 'no',
            brief => {},
            detailed => {},
            type => 'Date'
          }
        ]
      },
      brief => {
        doc => [
          {
            type => 'parbreak'
          },
          {
            type => 'text',
            content => 'Class that defines a '
          },
          {
            type => 'url',
            link => 'class_room',
            content => 'Room'
          },
          {
            type => 'text',
            content => '. '
          }
        ]
      },
      detailed => {}
    }
  ],
  namespaces => [
  ],
  files => [
    {
      name => 'Date.cpp',
      includes => [
        {
          name => 'stdafx.h',
          ref => 'stdafx_8h'
        },
        {
          name => 'Date.h',
          ref => '_date_8h'
        }
      ],
      included_by => [
      ],
      brief => {},
      detailed => {}
    },
    {
      name => 'Date.h',
      includes => [
      ],
      included_by => [
        {
          name => 'Date.cpp',
          ref => '_date_8cpp'
        },
        {
          name => 'Room.h',
          ref => '_room_8h'
        },
        {
          name => 'project_1_Hotel.cpp',
          ref => 'project__1___hotel_8cpp'
        }
      ],
      brief => {},
      detailed => {}
    },
    {
      name => 'here.txt',
      includes => [
      ],
      included_by => [
      ],
      brief => {},
      detailed => {}
    },
    {
      name => 'Hotel.cpp',
      includes => [
        {
          name => 'stdafx.h',
          ref => 'stdafx_8h'
        },
        {
          name => 'Hotel.h',
          ref => '_hotel_8h'
        },
        {
          name => 'iostream'
        },
        {
          name => 'fstream'
        }
      ],
      included_by => [
      ],
      brief => {},
      detailed => {}
    },
    {
      name => 'Hotel.h',
      includes => [
        {
          name => 'Room.h',
          ref => '_room_8h'
        },
        {
          name => 'iostream'
        },
        {
          name => 'vector'
        }
      ],
      included_by => [
        {
          name => 'Hotel.cpp',
          ref => '_hotel_8cpp'
        },
        {
          name => 'project_1_Hotel.cpp',
          ref => 'project__1___hotel_8cpp'
        }
      ],
      brief => {},
      detailed => {}
    },
    {
      name => 'input_hotel.txt',
      includes => [
      ],
      included_by => [
      ],
      brief => {},
      detailed => {}
    },
    {
      name => 'project_1_Hotel.cpp',
      includes => [
        {
          name => 'iostream'
        },
        {
          name => 'string'
        },
        {
          name => 'Date.h',
          ref => '_date_8h'
        },
        {
          name => 'Room.h',
          ref => '_room_8h'
        },
        {
          name => 'Hotel.h',
          ref => '_hotel_8h'
        },
        {
          name => 'fstream'
        },
        {
          name => 'ctime'
        }
      ],
      included_by => [
      ],
      functions => {
        members => [
          {
            kind => 'function',
            name => 'main',
            virtualness => 'non_virtual',
            protection => 'public',
            static => 'no',
            brief => {},
            detailed => {},
            type => '﻿ int',
            const => 'no',
            volatile => 'no',
            parameters => [
            ]
          }
        ]
      },
      brief => {},
      detailed => {}
    },
    {
      name => 'Room.cpp',
      includes => [
        {
          name => 'stdafx.h',
          ref => 'stdafx_8h'
        },
        {
          name => 'Room.h',
          ref => '_room_8h'
        }
      ],
      included_by => [
      ],
      brief => {},
      detailed => {}
    },
    {
      name => 'Room.h',
      includes => [
        {
          name => 'Date.h',
          ref => '_date_8h'
        },
        {
          name => 'string'
        }
      ],
      included_by => [
        {
          name => 'Hotel.h',
          ref => '_hotel_8h'
        },
        {
          name => 'project_1_Hotel.cpp',
          ref => 'project__1___hotel_8cpp'
        },
        {
          name => 'Room.cpp',
          ref => '_room_8cpp'
        }
      ],
      brief => {},
      detailed => {}
    },
    {
      name => 'savemehere.txt',
      includes => [
      ],
      included_by => [
      ],
      brief => {},
      detailed => {}
    },
    {
      name => 'stdafx.cpp',
      includes => [
        {
          name => 'stdafx.h',
          ref => 'stdafx_8h'
        }
      ],
      included_by => [
      ],
      brief => {},
      detailed => {}
    },
    {
      name => 'stdafx.h',
      includes => [
        {
          name => 'targetver.h',
          ref => 'targetver_8h'
        },
        {
          name => 'stdio.h'
        },
        {
          name => 'tchar.h'
        }
      ],
      included_by => [
        {
          name => 'Date.cpp',
          ref => '_date_8cpp'
        },
        {
          name => 'Hotel.cpp',
          ref => '_hotel_8cpp'
        },
        {
          name => 'Room.cpp',
          ref => '_room_8cpp'
        },
        {
          name => 'stdafx.cpp',
          ref => 'stdafx_8cpp'
        }
      ],
      brief => {},
      detailed => {}
    },
    {
      name => 'targetver.h',
      includes => [
        {
          name => 'SDKDDKVer.h'
        }
      ],
      included_by => [
        {
          name => 'stdafx.h',
          ref => 'stdafx_8h'
        }
      ],
      brief => {},
      detailed => {}
    }
  ],
  groups => [
  ],
  pages => [
  ]
};
1;
